print(f'Invoking __init__.py for {__name__}')

import neural.func
import neural.draw
